import io
import psycopg2
import json

with io.open ('data/dataset.jsonl', 'r',encoding='utf-8' ) as f:
    data = f.read()

js = json.loads(data)


# Подключаемся к PostgreSQL
conn = psycopg2.connect(dbname='ansquest', user='user1', password='user1', host='10.240.7.109', port=5432)
cursor = conn.cursor()

for item in js:
    sql = "INSERT INTO chats_answer (answer) VALUES('"+item['passage'].replace('\n', ' ').replace("'",'"')+"') returning id;"
    cursor.execute(sql)
    s=cursor.fetchone()
    conn.commit()
    sql = "INSERT INTO chats_question (question, answer_id) VALUES('"+item['question']+"',"+str(s[0])+')'
    cursor.execute(sql)
    conn.commit()
conn.close()



