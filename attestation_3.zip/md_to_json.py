import io
import json

import markdown_to_json

with io.open('data/400.md', encoding='utf-8') as f:
    value = f.read()
ans = dict(markdown_to_json.dictify(value))

with io.open ('data/dataset.jsonl', 'w', encoding='utf-8') as f:
    for item in ans:
        d = {}
        d['question'] = item
        d['passage'] = ans[item]
        f.write(json.dumps(d, ensure_ascii=False))
        f.write('\n')
